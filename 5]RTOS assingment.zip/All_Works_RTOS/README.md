# RTOS
Learning Purpose
---
## DAY 1
1. Logical and Temporal
1. Real Time System
---
## DAY 2
1. FreeRTOS
1. Different Between GPOS  and RTOS
1. Non-preemptive kernel
1. preemptive kernel
1. Interrupt latency
1. Interrupt response
1. Interrupt recovery
---
## DAY 3
1. periodic Task
1. Aperiodic Task
1. Sporadic Task
1. Simple Hello Program
1. Simple Multi Task Program
---
## DAY 4
1. Creating Multi Tasking
---
## DAY 5
1. Periodic Task
1. Stack Utility
1. CPU Affinity
1. Queue
1. Semaphore
1. Suspend and resume
1. Counting semaphore
---
## DAY 6
1. Timer
1. Event Group
---
## MODULE ASSIGNMENT 
1. question 10 answer![tskstate](https://user-images.githubusercontent.com/94945524/150633400-8cd51a37-7906-42a8-97c1-8df1fad5e4d5.gif)
---