#include <stdio.h>

void app_main()
{
    printf("HELLO C-DAC\n");
}